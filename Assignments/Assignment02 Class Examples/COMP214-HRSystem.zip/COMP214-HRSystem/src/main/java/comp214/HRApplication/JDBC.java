package comp214.HRApplication;

import java.sql.*;

public class JDBC {

    static final String DRIVER = "oracle.jdbc.OracleDriver";
    static final String DATABASE_URL = "jdbc:oracle:thin:@199.212.26.208:1521:SQLD";
    static final String USERNAME = "COMP214_F22_er_49";
    static final String PASSWORD = "password";


}
