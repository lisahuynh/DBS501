for local database connection, $conn = oci_connect("system", "manager", "//localhost/XE");
for remote database connection, $conn = oci_connect("COMP214_F22_er_9", "Atom58198618", "//199.212.26.208:1521/SQLD");


Our application is based on the PHP+oracle database.

The tool I use to create my PHP environment is Wampserver.

Please use homepage.php to begin the application.

We referenced the following websites.

https://www.oracle.com/technical-resources/articles/fuecks-sps.html
https://www.oracle.com/technetwork/cn/tutorials/229068-zhs.htm
http://www.learn-coding.today/php_oracle_procedures.php
https://www.w3schools.com/html/html_layout.asp